user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);
